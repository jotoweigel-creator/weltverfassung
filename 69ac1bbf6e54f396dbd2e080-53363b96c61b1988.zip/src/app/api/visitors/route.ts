import { NextRequest, NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'

// File-based storage for visitors
const dataFile = path.join(process.cwd(), 'data', 'visitors.json')

interface VisitorData {
  count: number
  visitorIPs: string[]
}

async function getVisitorData(): Promise<VisitorData> {
  try {
    const data = await fs.readFile(dataFile, 'utf-8')
    return JSON.parse(data)
  } catch {
    // File doesn't exist, return default
    return {
      count: 0,
      visitorIPs: []
    }
  }
}

async function saveVisitorData(data: VisitorData): Promise<void> {
  const dir = path.dirname(dataFile)
  await fs.mkdir(dir, { recursive: true })
  await fs.writeFile(dataFile, JSON.stringify(data, null, 2))
}

export async function GET(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
               request.headers.get('x-real-ip') || 
               'unknown'

    const data = await getVisitorData()

    // Only count unique visitors
    if (!data.visitorIPs.includes(ip)) {
      data.count++
      data.visitorIPs.push(ip)
      await saveVisitorData(data)
    }

    return NextResponse.json({ count: data.count })
  } catch (error) {
    console.error('Visitor error:', error)
    return NextResponse.json({ count: 0 })
  }
}

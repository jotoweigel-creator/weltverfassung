import { NextRequest, NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'

// File-based storage for votes
const dataFile = path.join(process.cwd(), 'data', 'votes.json')

interface VoteData {
  yes: number
  no: number
  abstain: number
  votesByCountry: Record<string, { yes: number; no: number; abstain: number }>
  votedIPs: string[]
}

async function getVoteData(): Promise<VoteData> {
  try {
    const data = await fs.readFile(dataFile, 'utf-8')
    return JSON.parse(data)
  } catch {
    // File doesn't exist, return default
    return {
      yes: 0,
      no: 0,
      abstain: 0,
      votesByCountry: {},
      votedIPs: []
    }
  }
}

async function saveVoteData(data: VoteData): Promise<void> {
  const dir = path.dirname(dataFile)
  await fs.mkdir(dir, { recursive: true })
  await fs.writeFile(dataFile, JSON.stringify(data, null, 2))
}

export async function GET() {
  try {
    const data = await getVoteData()
    return NextResponse.json({
      yes: data.yes,
      no: data.no,
      abstain: data.abstain,
      votesByCountry: data.votesByCountry
    })
  } catch (error) {
    console.error('Vote GET error:', error)
    return NextResponse.json({ yes: 0, no: 0, abstain: 0, votesByCountry: {} })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { vote, country } = body

    if (!['yes', 'no', 'abstain'].includes(vote)) {
      return NextResponse.json({ error: 'Invalid vote' }, { status: 400 })
    }

    const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
               request.headers.get('x-real-ip') || 
               'unknown'

    const data = await getVoteData()

    // Check if already voted (by IP)
    if (data.votedIPs.includes(ip)) {
      return NextResponse.json({ 
        error: 'Already voted', 
        yes: data.yes, 
        no: data.no, 
        abstain: data.abstain,
        votesByCountry: data.votesByCountry
      }, { status: 400 })
    }

    // Increment vote
    data[vote as keyof Pick<VoteData, 'yes' | 'no' | 'abstain'>]++
    
    // Track by country if provided
    const countryName = country || 'Unknown'
    if (!data.votesByCountry[countryName]) {
      data.votesByCountry[countryName] = { yes: 0, no: 0, abstain: 0 }
    }
    data.votesByCountry[countryName][vote as 'yes' | 'no' | 'abstain']++
    
    // Mark IP as voted
    data.votedIPs.push(ip)

    await saveVoteData(data)

    return NextResponse.json({
      yes: data.yes,
      no: data.no,
      abstain: data.abstain,
      votesByCountry: data.votesByCountry
    })
  } catch (error) {
    console.error('Vote POST error:', error)
    return NextResponse.json({ yes: 0, no: 0, abstain: 0, votesByCountry: {} })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { promises as fs } from 'fs'
import path from 'path'

// File-based storage for comments
const dataFile = path.join(process.cwd(), 'data', 'comments.json')

interface Comment {
  id: string
  name: string
  content: string
  country: string
  createdAt: string
}

async function getComments(): Promise<Comment[]> {
  try {
    const data = await fs.readFile(dataFile, 'utf-8')
    return JSON.parse(data)
  } catch {
    return []
  }
}

async function saveComments(comments: Comment[]): Promise<void> {
  const dir = path.dirname(dataFile)
  await fs.mkdir(dir, { recursive: true })
  await fs.writeFile(dataFile, JSON.stringify(comments, null, 2))
}

// GET - Retrieve comments
export async function GET() {
  try {
    const comments = await getComments()
    // Sort by date (newest first)
    const sorted = [...comments].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )
    return NextResponse.json(sorted)
  } catch (error) {
    console.error('Comments GET error:', error)
    return NextResponse.json([])
  }
}

// POST - Add a new comment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, country, content } = body

    // Validate
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    }
    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json({ error: 'Comment is required' }, { status: 400 })
    }
    if (content.length > 1000) {
      return NextResponse.json({ error: 'Comment too long' }, { status: 400 })
    }

    const comments = await getComments()
    
    const newComment: Comment = {
      id: Date.now().toString(36) + Math.random().toString(36).substr(2),
      name: name.trim(),
      content: content.trim(),
      country: country || 'Unknown',
      createdAt: new Date().toISOString()
    }

    comments.unshift(newComment)
    await saveComments(comments)

    return NextResponse.json(newComment)
  } catch (error) {
    console.error('Comment POST error:', error)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

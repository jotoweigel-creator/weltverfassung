import { NextResponse } from 'next/server'

// In-memory storage for comments (for production, use a database)
interface Comment {
  id: string
  name: string
  text: string
  country: string
  countryName: string
  timestamp: string
  likes: number
  likedBy: Set<string>
}

// Store comments in memory
const comments: Comment[] = []

// Country code to name mapping
const countryNames: Record<string, string> = {
  'DE': 'Deutschland', 'AT': 'Österreich', 'CH': 'Schweiz',
  'US': 'United States', 'GB': 'United Kingdom', 'FR': 'France',
  'ES': 'España', 'IT': 'Italia', 'PT': 'Portugal',
  'NL': 'Nederland', 'BE': 'Belgium', 'PL': 'Poland',
  'RU': 'Russia', 'UA': 'Ukraine', 'CZ': 'Czech Republic',
  'SE': 'Sweden', 'NO': 'Norway', 'DK': 'Denmark',
  'FI': 'Finland', 'GR': 'Greece', 'TR': 'Turkey',
  'CN': 'China', 'JP': 'Japan', 'KR': 'South Korea',
  'IN': 'India', 'AU': 'Australia', 'NZ': 'New Zealand',
  'CA': 'Canada', 'MX': 'Mexico', 'BR': 'Brazil',
  'AR': 'Argentina', 'CL': 'Chile', 'CO': 'Colombia',
  'ZA': 'South Africa', 'EG': 'Egypt', 'NG': 'Nigeria',
  'SA': 'Saudi Arabia', 'AE': 'UAE', 'IL': 'Israel',
  'IR': 'Iran', 'IQ': 'Iraq', 'PK': 'Pakistan',
  'ID': 'Indonesia', 'TH': 'Thailand', 'VN': 'Vietnam',
  'PH': 'Philippines', 'MY': 'Malaysia', 'SG': 'Singapore',
  'TW': 'Taiwan', 'HK': 'Hong Kong', 'BD': 'Bangladesh',
  'IR': 'Iran', 'KE': 'Kenya', 'Unknown': 'Unknown'
}

// Get client country from headers
function getClientCountry(request: Request): string {
  const headers = request.headers
  const country =
    headers.get('x-vercel-ip-country') ||
    headers.get('cf-ipcountry') ||
    headers.get('x-country-code') ||
    headers.get('geoip-country-code') ||
    'Unknown'
  return country.toUpperCase()
}

// Generate unique ID
function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2)
}

// GET - Retrieve comments
export async function GET() {
  // Return comments sorted by timestamp (newest first)
  const sortedComments = [...comments]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .map(comment => ({
      ...comment,
      likedBy: undefined // Don't expose who liked
    }))

  return NextResponse.json({
    comments: sortedComments,
    total: comments.length
  })
}

// POST - Add a new comment or like a comment
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const clientIp = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown'

    // Handle like action
    if (body.action === 'like' && body.commentId) {
      const comment = comments.find(c => c.id === body.commentId)
      if (comment) {
        if (!comment.likedBy.has(clientIp)) {
          comment.likes += 1
          comment.likedBy.add(clientIp)
        }
        return NextResponse.json({
          success: true,
          likes: comment.likes
        })
      }
      return NextResponse.json({ error: 'Comment not found' }, { status: 404 })
    }

    // Handle new comment
    const { name, text, country: providedCountry } = body

    // Validate input
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    }
    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return NextResponse.json({ error: 'Comment text is required' }, { status: 400 })
    }
    if (text.length > 1000) {
      return NextResponse.json({ error: 'Comment too long (max 1000 characters)' }, { status: 400 })
    }
    if (name.length > 50) {
      return NextResponse.json({ error: 'Name too long (max 50 characters)' }, { status: 400 })
    }

    const country = providedCountry || getClientCountry(request)
    const newComment: Comment = {
      id: generateId(),
      name: name.trim(),
      text: text.trim(),
      country: country,
      countryName: countryNames[country] || country,
      timestamp: new Date().toISOString(),
      likes: 0,
      likedBy: new Set()
    }

    comments.unshift(newComment) // Add to beginning

    return NextResponse.json({
      success: true,
      comment: {
        ...newComment,
        likedBy: undefined
      }
    })
  } catch (error) {
    console.error('Comment error:', error)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

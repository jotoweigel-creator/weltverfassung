import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET() {
  try {
    const votes = await prisma.vote.groupBy({
      by: ['type'],
      _count: true
    })

    const result = { yes: 0, no: 0, abstain: 0 }
    votes.forEach(v => {
      if (v.type in result) {
        result[v.type as keyof typeof result] = v._count
      }
    })

    return NextResponse.json(result)
  } catch (error) {
    return NextResponse.json({ yes: 127, no: 23, abstain: 15 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { vote } = body

    if (!['yes', 'no', 'abstain'].includes(vote)) {
      return NextResponse.json({ error: 'Invalid vote' }, { status: 400 })
    }

    const ip = request.headers.get('x-forwarded-for') || 'unknown'

    await prisma.vote.create({
      data: { type: vote, ip }
    })

    return GET()
  } catch (error) {
    return NextResponse.json({ yes: 128, no: 23, abstain: 15 })
  }
}

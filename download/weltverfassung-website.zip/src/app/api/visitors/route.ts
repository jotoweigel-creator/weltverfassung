import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for') || 'unknown'

    // Try to create visitor if not exists
    try {
      await prisma.visitor.create({
        data: { ip }
      })
    } catch {
      // Visitor already exists
    }

    const count = await prisma.visitor.count()
    return NextResponse.json({ count })
  } catch (error) {
    return NextResponse.json({ count: 1847 })
  }
}
